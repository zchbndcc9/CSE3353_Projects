# Instructions

## Enter node run __ into the command line with the arguments provided in the list below. If you would like to modify the images being modified, edit the input args in the index.js file.

- Grayscale: `node index.js gray`

- Blur: `node index.js blur`

- Sharpen: `node index.js sharpen`

- Connect: `node index.js connect`

- Graph: `node index.js graph`

## All resulting images will be stored in the Images directory


